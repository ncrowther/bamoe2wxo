export CLOUDANT_URL=https://724c8e7f-5faa-49e1-8dc0-7a39ffd871ad-bluemix.cloudantnosqldb.appdomain.cloud
export CLOUDANT_APIKEY=MnzpcY1I5LpUG2mtl4a-_93qBxL2PAXakBn6Pf-CIg69
export DBNAME=katchdb
