# WXO Cloudant Facade

### Folders

   * dataservice -  a Nodejs Database facade on top of Cloudant and an OpenAPI spec with which to invoke it.  See  [Readme](\dataservice\readme.md) for more info
   * bots -  A RPA bots to read and write to Cloudant database

   
